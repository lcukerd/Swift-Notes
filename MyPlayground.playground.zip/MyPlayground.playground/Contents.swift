// Swift naming Convention
var firstName = "Harshit"
let name = firstName

// Type annotations, No default values in Swift
var bonus: Int
var environment: String
var nameArray: [String]                     // Type annotation required when declaring empty array


//Constants
let constant = 58

let width: Int
// but must be initialised before using it
width = 23

//Operators
let sum = constant + width
// ++ -- operators not available in Swift


let quotient = 5 / 2
type(of: quotient)

let quotientF = 5.0 / 2
type(of: quotientF)

// No implicit conversion in Swift (P.S. only variables will show this behaviour not literals)

// Explicit Conversion (Can't do bool to int etc)
let numberS = "34.5"
let number = Int(numberS)                   // Not gonna throw error but might return nil
type(of: number)
let numberF = Float(numberS)

// Optionals
var middleName: String?
type(of: middleName)

// Can only initialze optional variable with nil explicitly and not normal variables
middleName = nil

middleName = "middle"

// Can't just use optional varible in equation, must unwrap first
if middleName != nil{
    var name = middleName!           // Forced unwrapping, will crash if nil
    type(of: name)
}
// Or use Optional binding
if let name = middleName {
    type(of: name)
} else {
    // No value in middleName
}

// Collections
var musicalMode = ["Ionian", "Dorain", "Phrygian"]
let speedLimits = [15, 25, 35, 45]

let speed = speedLimits[2]
musicalMode.append("Locrian")
musicalMode.remove(at: 1)

// Braces are reqd, Parenthesis are not reqd in Swift
// Conditions must be true or false, 0 or 1 will not work
// And is && and so on...
// Use === to check if both reference to same object

// Each case must have an executable code, no fallthrough here (hence, no break reqd)
switch speed {
case 25:
    print("First")
case 35, 45:
    print("Second 😻")
case 1...4:                          // Compare for Range
    print ("Range")
default:
    print("Default")
}

// Do-while
var items = 2
repeat {
    items -= 1
} while items > 0

for mode in musicalMode {
    print(mode)
}

// Range is inclusive (Does not go in reverse)
for numbers in 0...3 {
    print (numbers)                 // Scope is for block
}
// This range is half-open
for numbers in 0..<3 {
    print (numbers)
}
for numbers in stride(from: 0, through: 10, by: 3){
    print (numbers)
}

// String Interpolation
let trackName = "Some"
let artistName = "Ed"
let duration = 300
let message = "Now playing \(trackName) by \(artistName) for \(duration/60)"

print (message)

// Functions
// Parameters are immutable
func showMessage(number: Int, name: String) -> Int{
    return 10
}
// Call must have labels with it
showMessage(number: 23, name: "Hello")

// Use _ to show intentionally ignoring something
_ = showMessage(number: 23, name: "Hello")          // Ignore return type

func showMessageNoLabel(_ number: Int,_ name: String) -> Int{
    return 10
}
showMessageNoLabel(23, "Hello")                     // Ignore label in fn calls

// Use nick-name label for fn call
func showMessageNick(first number: Int,second name: String) -> Int{
    return 10                                       // number and name will be used in fn though
}
showMessageNick(first: 23,second:  "Hello")

// Enumerations
// Naming Convention for data type, starts with upper case
enum MediaType{
    case book(String), movie(Int), music, game
}
var itemType: MediaType = .book("Good")           // Can omit Object name when data type is declared

//Struct no inheritance
struct Movie{
    // properties
    var title: String
    var diretor: String
    
    func summary() -> String {
        return "Summary"
    }
}

var first = Movie(title: "good", diretor: "bad")
first.title
first.summary()

// Struct are value type and classes are reference type
// Struct don't have deinit's
// Class must have intial values for all data members(can be done in init)
//
// Classes
class Appliance {
    var manufacturer: String
    var model: String
    var capacity: Int
    
    init() {
        self.manufacturer = ""
        self.model = ""
        self.capacity = 0
    }
    
    final func getDetails() -> String {         // Can't override this final fn now
        return "Detials"
    }
    
    deinit {
        // Destructors
    }
}

// Automatic Reference Counting (ARC) is Swift's garbage collector

var kettle = Appliance()
kettle.manufacturer

// Inheritance
class Toaster: Appliance {
    var slices: Int
    
    override init(){
        // First this is called then of base class
        self.slices = 2
    }
    
    func toast() {
        print("Toasting")
    }
}


// Dict
var airlines = ["Code": "Airplane"]
var dictionaru : [String: Int]
airlines["Code"]

for (code, airline) in airlines{
    print (code + airline)
}
// Remove key with value from dict
airlines["Code"] = nil

// Tuple (can be used to return multiple value from fn)
var basicTuple = (name, firstName)
basicTuple.0

// Closure is a block of code you intend to pass
// Passing function in function, similar to comparator. Also used in callbacks
// $0 and $1 denote first and second parameter of closure, are automatically defined
musicalMode.sorted { $0 <= $1 }

// Extensions
extension String {
    func removeSpaces() -> String {
        let filteredCharacters = self.filter {$0 != " "}
        return filteredCharacters
    }
}

name.removeSpaces()

// Computed Properties
class Player {
    var name: String = "Lucky"
    var livesRemaining: Int = 10
    var penalty: Int = 20
    var bonus: Int = 40
    
    // Cannot define it as const. can drop get and set and then enclosed code will treated as getter
    var score: Int {
        get{
            return (bonus - penalty)
        }
        set{
            print ("\(newValue) being ignored")
        }
    }
}

var player = Player()
player.score

// Protocols (basically Interface)
class PlayerN: CustomStringConvertible {
    var name: String = "Lucky"
    var livesRemaining: Int = 10
    var penalty: Int = 20
    var bonus: Int = 40
    
    var description: String {
        return "Description"
    }
    // Cannot define it as const. can drop get and set and then enclosed code will treated as getter
    var score: Int {
        get{
            return (bonus - penalty)
        }
        set{
            print ("\(newValue) being ignored")
        }
    }
}

print(PlayerN())

// Defining protocol

protocol MyProtocol{
    func showMessage()
    
    var name: String { get }
}

// Adopt protocol is declaring where its used, conform is setting up to actually use
struct MyStruct: MyProtocol{
    func showMessage() {
        print ("Conforming Protocol")
    }
    var name: String {
        return "Sebastion"
    }
}

// Error Handling
enum ServerError: Error{
    case noConnection
    case serverNotFound
    case authenticationRefused
}

func checkStatus(ServerNumber: Int) throws -> String {
    switch ServerNumber {
    case 1:
        print ("No Connection")
        throw ServerError.noConnection
    default:
        print ("Other")
        throw ServerError.serverNotFound
    }
    return "Success!"
}

do {
    print (try checkStatus(ServerNumber: 1))
} catch ServerError.noConnection{
    print ("No Connection")
} catch {
    print("The problem is: \(error)")
}
// Shorter version: nil if error thrown else returned value
print(try? checkStatus(ServerNumber: 1))

// Guard
// Drop to else if condition is false else don't do anything
// Scope of variable declared in condition of guard is outside guard block

// Defer
// defer block will be executed when that block goes out of scope
